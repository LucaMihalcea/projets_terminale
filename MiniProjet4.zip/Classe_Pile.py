#Classe Pile du cours 

class Pile():

    def __init__(self):
        self._structure=[]
        self._taille=0

    def estvide(self):
        return self._taille==0

    def sommet(self):
        assert not self.estvide(),'La pile est vide'
        return self._structure[-1]

    def empiler(self,elt):
        self._structure.append(elt)
        self._taille+=1

    def depiler(self):
        assert not self.estvide(),'La pile est vide'
        self._taille-=1
        return self._structure.pop()

    def __repr__(self):
        return(str(self._structure)+str("<-- sommet"))