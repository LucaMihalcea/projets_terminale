from Trouver_le_chemin_V1 import*

#initialisation des graphs testés 
G1 = {1: [4], 2: [1,5], 3: [1,2], 4: [7], 5: [3,4], 6: [4,5,7,8], 7: [], 8: [5,7]}
G2 = {1: [5], 2: [1,4], 3: [2], 4: [3], 5: [2,4]}
G3 = {1: [3,4,5,6], 2: [1], 3: [2,4], 4: [], 5: [], 6: [4]}

#test fonction parcours_profondeur
assert parcours_profondeur(G1, 1) == [1, 4, 7]
assert parcours_profondeur(G2, 1) == [1, 5, 2, 4, 3]
assert parcours_profondeur(G3, 1) == [1, 3, 2, 4, 5, 6]


#test fonction estvoisin
assert estvoisin(G1, 4, 1)
assert not estvoisin(G2, 3, 2)
assert estvoisin(G3, 4, 3)

#test fonction chemin 
assert chemin(G1, 1, 7) == [1, 4, 7]
assert chemin(G2, 3, 5) == [3, 2, 1, 5]
assert chemin(G3, 1, 6) == [1, 6]
