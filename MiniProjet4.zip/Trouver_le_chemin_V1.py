from Classe_Pile import Pile

#voir la representation sagitale dans le dossier pour le graph representatif du labyrinthe
graph_representatif_labyrinthe = {1 : [2], 2: [1,3,4], 3: [2], 4: [2,5,6], 5: [4], 6: [7,8], 7: [6], 8: [6]}

def parcours_profondeur(G: dict,x: int):
    """
    Effectue le parcours en profondeur d'un graph sous la forme de dictionnaire en partant d'un sommet x
    """
    #preconditions
    assert len(G) > 0 and x in G.keys()

    parcours = []
    pile=Pile()
    pile.empiler(x)
    while not pile.estvide():
        s=pile.sommet()
        pile.depiler()
        if s not in parcours:   # non déjà visité
            parcours.append(s)   # on ajoute le sommet au parcours
            for successeur in reversed(G[s]): # on examine les successeurs
                if successeur not in parcours:   # si non déjà visités
                    pile.empiler(successeur)
    return parcours


def estvoisin(G: dict, sommet_presume_voisin: int, sommet: int) -> bool:
    """
    Permet de verifier si un sommet est le voisin d'un autre sommet
    """
    return sommet_presume_voisin in G[sommet] 

def chemin(G: dict, depart: int, sortie: int)-> list:
    """
    Permet de trouver un chemin dans un graph allant d'un sommet de départ à un sommet de sortie
    """
    parcours = parcours_profondeur(G, depart)
    for i in range(len(parcours)): #boucle pernettant de garder du parcours en profondeur la partie qui nous interresse c'est a dire du depart a la sortie (pour notre graph du sommet 1 au 8)
        if parcours[i] == sortie:
            indice_fin = i 
    parcours2 = parcours[:indice_fin + 1]
    for i in range(len(parcours2)): #on repete l'operation pour tout les sommets
        while indice_fin >= 1 and not estvoisin(G, parcours2[indice_fin], parcours2[indice_fin - 1]): #on regarde si le sommet avant le sommet d'arrivée est un de ses voisins, pour eliminer les sommets inutiles dans le parcours et on le repete pour tout les sommets
            parcours2.pop(indice_fin - 1) #si le sommet precedent n'est pas un voisin, on le retire dans le but d'avoir un chemin ou chaque sommet est un voisin du suivant et du precedent
            indice_fin -= 1 #on a reduit la taille de la liste de sommets donc l"indice de fin est decale de 1
        indice_fin -= 1 #on change de sommet 
    return parcours2

print(chemin(graph_representatif_labyrinthe, 1, 8))